import MyAgent from "./Components/MyAgent/MyAgent";
import PluginStore from "./Components/PluginStore/PluginStore";

function App() {
  return (
    <>
      <PluginStore />
      <MyAgent />
    </>
  );
}

export default App;
