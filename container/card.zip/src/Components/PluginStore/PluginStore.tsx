import { useState } from "react";
import AgentCard from "../AgentCard";
import { Button } from "antd";

function PluginStore() {
  const filterButton = [
    {
      name: "全部",
      type: "all",
    },
    {
      name: "MCP",
      type: "mcp",
    },
  ];

  const [originalData, setOriginalData] = useState([
    {
      typeName: "", // 可选字段，类型名称
      previewUrl:
        "https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg?auto=compress&cs=tinysrgb&w=600", // 预览图片 URL
      title: "文生图", // 标题
      description: "只需输入文字描述，就能创作出各种独特的图像作品。", // 描述
      date: "2023-10-01", // 日期
      rootTag: "@荣耀官方", // 根标签
    },
    {
      typeName: "MCP2", // 可选字段，类型名称
      previewUrl:
        "https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg?auto=compress&cs=tinysrgb&w=600", // 预览图片 URL
      title: "文生图", // 标题
      description: "只需输入文字描述，就能创作出各种独特的图像作品。", // 描述
      date: "2023-10-01", // 日期
      rootTag: "@荣耀官方", // 根标签
    },
    {
      typeName: "", // 可选字段，类型名称
      previewUrl:
        "https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg?auto=compress&cs=tinysrgb&w=600", // 预览图片 URL
      title: "文生图", // 标题
      description: "只需输入文字描述，就能创作出各种独特的图像作品。", // 描述
      date: "2023-10-01", // 日期
      rootTag: "@荣耀官方", // 根标签
    },
    {
      typeName: "", // 可选字段，类型名称
      previewUrl:
        "https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg?auto=compress&cs=tinysrgb&w=600", // 预览图片 URL
      title: "文生图", // 标题
      description: "只需输入文字描述，就能创作出各种独特的图像作品。", // 描述
      date: "2023-10-01", // 日期
      rootTag: "@荣耀官方", // 根标签
    },
    {
      typeName: "MCP3", // 可选字段，类型名称
      previewUrl:
        "https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg?auto=compress&cs=tinysrgb&w=600", // 预览图片 URL
      title: "文生图", // 标题
      description: "只需输入文字描述，就能创作出各种独特的图像作品。", // 描述
      date: "2023-10-01", // 日期
      rootTag: "@荣耀官方", // 根标签
    },
    {
      typeName: "mcp", // 可选字段，类型名称
      previewUrl:
        "https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg?auto=compress&cs=tinysrgb&w=600", // 预览图片 URL
      title: "文生图", // 标题
      description: "只需输入文字描述，就能创作出各种独特的图像作品。", // 描述
      date: "2023-10-01", // 日期
      rootTag: "@荣耀官方", // 根标签
    },
    {
      typeName: "mcp", // 可选字段，类型名称
      previewUrl:
        "https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg?auto=compress&cs=tinysrgb&w=600", // 预览图片 URL
      title: "文生图", // 标题
      description: "只需输入文字描述，就能创作出各种独特的图像作品。", // 描述
      date: "2023-10-01", // 日期
      rootTag: "@荣耀官方", // 根标签
    },
    {
      typeName: "mcp", // 可选字段，类型名称
      previewUrl:
        "https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg?auto=compress&cs=tinysrgb&w=600", // 预览图片 URL
      title: "文生图", // 标题
      description: "只需输入文字描述，就能创作出各种独特的图像作品。", // 描述
      date: "2023-10-01", // 日期
      rootTag: "@荣耀官方", // 根标签
    },
  ]);
  let [showCardData, setShowCardData] = useState(originalData);

  function getFilterData(buttonInfo: { name: string; type: string }) {
    if (buttonInfo.type === "all") {
      setShowCardData([...originalData]);
      return;
    }
    showCardData = originalData.filter(
      (card) => card.typeName === buttonInfo.type
    );
    setShowCardData([...showCardData]);
  }

  return (
    <>
      <div
        style={{
          backgroundColor: "#f5f5f5ff",
          width: "100vw",
          height: "100vh",
          display: "flex",
          flexDirection: "column",
          padding: "20px",
        }}
      >
        <div
          className="filter-group"
          style={{
            display: "flex",
            gap: "10px",
            marginBottom: "40px",
          }}
        >
          {filterButton.map((button, index) => (
            <Button onClick={() => getFilterData(button)} key={index}>
              {button.name}
            </Button>
          ))}
        </div>
        <div
          className="card-group"
          style={{
            display: "flex",
            gap: "10px",
            flexWrap: "wrap",
          }}
        >
          {showCardData.map((card, index) => (
            <AgentCard key={index} data={card} />
          ))}
        </div>
      </div>
    </>
  );
}

export default PluginStore;
