import { useState } from "react";
import AgentCard from "../AgentCard";
import { CardType } from "../../Enum/CardType";
import { AuditOutlined, ContainerOutlined } from "@ant-design/icons";

function MyAgent() {

  const [originalData, setOriginalData] = useState([
    {
      cardType: CardType.MY_AGENT,
      previewUrl:
        "https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg?auto=compress&cs=tinysrgb&w=600", // 预览图片 URL
      title: "文生图", // 标题
      description: "只需输入文字描述，就能创作出各种独特的图像作品。", // 描述
      rootTag: "@荣耀官方", // 根标签
      rootTagIcon: <ContainerOutlined />,
      operation: [
        {
          type: "edit",
          operationName: "编辑",
        },
        {
          type: "edit",
          operationName: "删除",
        },
      ],
    },
    {
      cardType: CardType.MY_AGENT,
      previewUrl:
        "https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg?auto=compress&cs=tinysrgb&w=600", // 预览图片 URL
      title: "文生图", // 标题
      description: "只需输入文字描述，就能创作出各种独特的图像作品。", // 描述
      rootTag: "@荣耀官方", // 根标签
      rootTagIcon: <ContainerOutlined />,
    },
    {
      cardType: CardType.MY_AGENT,
      previewUrl:
        "https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg?auto=compress&cs=tinysrgb&w=600", // 预览图片 URL
      title: "文生图", // 标题
      description: "只需输入文字描述，就能创作出各种独特的图像作品。", // 描述
      rootTag: "@荣耀官方", // 根标签
      rootTagIcon: <ContainerOutlined />,
    },
    {
      cardType: CardType.MY_AGENT,
      previewUrl:
        "https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg?auto=compress&cs=tinysrgb&w=600", // 预览图片 URL
      title: "文生图", // 标题
      description: "只需输入文字描述，就能创作出各种独特的图像作品。", // 描述
      rootTag: "@荣耀官方", // 根标签
      rootTagIcon: <ContainerOutlined />,
    },
    {
      cardType: CardType.MY_AGENT,
      previewUrl:
        "https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg?auto=compress&cs=tinysrgb&w=600", // 预览图片 URL
      title: "文生图", // 标题
      description: "只需输入文字描述，就能创作出各种独特的图像作品。", // 描述
      rootTag: "@荣耀官方", // 根标签
      rootTagIcon: <ContainerOutlined />,
    },
    {
      cardType: CardType.MY_AGENT,
      previewUrl:
        "https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg?auto=compress&cs=tinysrgb&w=600", // 预览图片 URL
      title: "文生图", // 标题
      description: "只需输入文字描述，就能创作出各种独特的图像作品。", // 描述
      rootTag: "@荣耀官方", // 根标签
      rootTagIcon: <ContainerOutlined />,
    },
    {
      cardType: CardType.MY_AGENT,
      previewUrl:
        "https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg?auto=compress&cs=tinysrgb&w=600", // 预览图片 URL
      title: "文生图", // 标题
      description: "只需输入文字描述，就能创作出各种独特的图像作品。", // 描述
      rootTag: "@荣耀官方", // 根标签
      rootTagIcon: <AuditOutlined />,
    },
    {
      cardType: CardType.MY_AGENT,
      previewUrl:
        "https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg?auto=compress&cs=tinysrgb&w=600", // 预览图片 URL
      title: "文生图", // 标题
      description: "只需输入文字描述，就能创作出各种独特的图像作品。", // 描述
      rootTag: "@荣耀官方", // 根标签
      rootTagIcon: <ContainerOutlined />,
    },
  ]);
  let [showCardData, setShowCardData] = useState(originalData);

  return (
    <>
      <div
        style={{
          backgroundColor: "#f5f5f5ff",
          width: "100vw",
          height: "100vh",
          display: "flex",
          flexDirection: "column",
          padding: "20px",
        }}
      >
        <div
          className="card-group"
          style={{
            display: "flex",
            gap: "10px",
            flexWrap: "wrap",
          }}
        >
          {showCardData.map((card, index) => (
            <AgentCard key={index} data={card} />
          ))}
        </div>
      </div>
    </>
  );
}

export default MyAgent;
