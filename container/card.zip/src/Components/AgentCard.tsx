import { Button } from "antd";
import { CardType } from "../Enum/CardType";
import "./AgentCard.css";
import type { JSX } from "react";

interface IProps {
  data: {
    cardType?: CardType;
    typeName?: string;
    previewUrl: string;
    title: string;
    description: string;
    date?: string;
    rootTag: string;
    rootTagIcon?: JSX.Element;
    operation?: Record<string, string>[];
  };
}

const TitleClassName = {
  [CardType.MY_AGENT]: "my-agent-title",
  [CardType.PLUGIN_STORE]: "plugin-store-title",
};

const CardWrapClassName = {
  [CardType.MY_AGENT]: "my-agent-card-wrap",
  [CardType.PLUGIN_STORE]: "plugin-store-card-wrap",
};

function AgentCard(props: IProps) {
  const {
    rootTag,
    date,
    previewUrl,
    title,
    description,
    typeName,
    cardType,
    rootTagIcon,
    operation = [],
  } = props.data;

  return (
    <>
      <div className={CardWrapClassName[cardType || CardType.PLUGIN_STORE]}>
        <div className="top">
          <div className="left">
            <img src={previewUrl} alt={previewUrl} />
          </div>
          <div className="right">
            <div className="title">
              <div
                className={TitleClassName[cardType || CardType.PLUGIN_STORE]}
              >
                {title}
              </div>
              {typeName && <div className="type-name">{typeName}</div>}
            </div>
            <div className="description">{description}</div>
          </div>
        </div>
        <div className="bottom-wrap">
          <div className="bottom">
            <div className="root-tag-wrap">
              {rootTagIcon && <div>{rootTagIcon}</div>}
              <div>{rootTag}</div>
            </div>
            <div className="root-right">
              {date && <div> {date}</div>}
              {operation.map((item, index) => {
                return <Button style={{marginLeft: "10px"}} size="small"  color="default" variant="filled"  key={index}>{item.operationName}</Button>;
              })}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default AgentCard;
