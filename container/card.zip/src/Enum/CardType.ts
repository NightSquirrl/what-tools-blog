export enum CardType {
    MY_AGENT = "MY_AGENT",
    PLUGIN_STORE = "PLUGIN_STORE"
}